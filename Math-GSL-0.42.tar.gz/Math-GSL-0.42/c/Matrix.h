
gsl_matrix *gsl_matrix_vconcat(const gsl_matrix *A, const gsl_matrix *B);
gsl_matrix *gsl_matrix_hconcat(const gsl_matrix *A, const gsl_matrix *B);
void gsl_matrix_random(const gsl_matrix *A);
